LEARNSMART GHANA — PHONE-ONLY APK BUILD KIT

You need a free GitHub account and a web browser on your Android phone.

FILES
- .github/workflows/build-apk.yml: workflow file to create in your GitHub repository.
- LearnSmartGhana_Android_Project_v2.zip: upload this original project ZIP into the root of the repository.

STEPS
1. On your phone, open https://github.com and sign in or create an account.
2. Create a NEW PUBLIC repository named LearnSmartGhana (public repositories can use GitHub Actions without private-plan limits; do not upload personal secrets).
3. In the repository, choose Add file > Upload files. Upload LearnSmartGhana_Android_Project_v2.zip from your phone, then commit the change.
4. Create the workflow file: Add file > Create new file. For the filename, enter exactly:
   .github/workflows/build-apk.yml
5. Open the provided build-apk.yml file from this kit, copy all its contents, paste them into GitHub's new-file editor, then commit the file.
6. Open the repository's Actions tab. Select "Build LearnSmart Ghana APK" and tap Run workflow. If GitHub asks you to enable Actions, enable it.
7. Wait for the run to finish successfully. Open that run and scroll to Artifacts. Download "LearnSmartGhana-debug-apk". It downloads as a ZIP; extract it to get app-debug.apk.
8. Tap app-debug.apk to install. Android may ask you to allow installation from that browser or file manager. Only allow this for the APK you built from your own repository, then switch the permission off again afterward.

IMPORTANT
- This creates a DEBUG/test APK for trying the app, not a signed production release for Google Play.
- Google test ad IDs are used. Do not click your own ads. Configure real AdMob IDs and consent/privacy requirements before public release.
- Questions are sample practice questions, not official WAEC past papers. Obtain permission for copyrighted past papers.
- The workflow uses Gradle 8.9 and Java 17. If the build fails, open the failed Actions run and share the error text so it can be fixed.
